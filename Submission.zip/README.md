# NodeEJSMongo
A template repo designed to serve as a quick setup for web app projects using MongoDB, NodeJS and EJS
